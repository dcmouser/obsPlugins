Install this plugin into your streamdeck as normal.
You will have a single new button you can add which can be configured to send a websocket request.
Fill in values using a JSON playload and then click the button in your streamdeck UI to test it.
